import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import classes from "./History.module.css";

const History = () => {
  const historys = useSelector((state) => state.vin.history);
  const history = useHistory();
  const handleClick = (e) => {
    history.push(`/vindecode/${e}`);
  };
  return (
    <div className="jumbotron">
      <table className="table">
        <thead className="thead-light">
          <tr>
            <th scope="col">
              <h1>History</h1>
            </th>
          </tr>
        </thead>
        <tbody>
          {historys
            .slice(0)
            .reverse()
            .map((h) => (
              <tr>
                <td>
                  <button
                    className={classes.links}
                    onClick={() => handleClick(h)}
                  >
                    {h}
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
};

export default History;
