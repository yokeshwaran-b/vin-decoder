import "./AuthRegister.css";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import { resgisterUserAsync } from "../../store/user-slice";
import { useHistory } from "react-router";
import { useState, useEffect } from "react";
const AuthRegister = () => {
  const dispatch = useDispatch();
  const isUserCreated = useSelector((state) => state.user.isUserCreated);
  const history = useHistory();
  const [isSignedUp, setIsSignedUp] = useState(false);

  const onSubmit = (newUser) => {
    dispatch(resgisterUserAsync(newUser));
    setIsSignedUp(true);
  };

  useEffect(() => {
    if (isSignedUp && isUserCreated) {
      alert(`Successfully signed up`);
      history.push("login");
    }
  }, [isUserCreated, isSignedUp, history]);

  const error = useSelector((state) => state.user.userCreateError);

  const validationSchema = Yup.object({
    first_name: Yup.string().required("First name is Required!"),
    last_name: Yup.string().required("Last name is Required!"),
    email: Yup.string().required("Email is Required!").email("Invalid email"),
    password: Yup.string()
      .required("Password is Required!")
      .min(8, "Too Short!"),
    password_confirmation: Yup.string().oneOf(
      [Yup.ref("password"), null],
      "Passwords must match"
    ),
  });

  const formik = useFormik({
    initialValues: {
      first_name: "",
      last_name: "",
      email: "",
      password: "",
      password_confirmation: "",
    },
    onSubmit,
    validationSchema,
  });
  return (
    <>
      <div className="container mb-5">
        <div className="row centered-form">
          <div className="col-12 col-md-8 col-lg-4 offset-sm-2 offset-md-4">
            <div className="card">
              <div className="card-header">
                <h3 className="card-title">
                  Please sign up for Vin Decoder <small>It&apos;s free!</small>
                </h3>
              </div>
              <div className="card-body">
                <form onSubmit={formik.handleSubmit}>
                  <div className="row">
                    <div className="col-6 col-md-6 col-lg-6">
                      <div className="form-group">
                        <input
                          type="text"
                          name="first_name"
                          id="first_name"
                          value={formik.values.first_name}
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          className="form-control form-control-sm"
                          placeholder="First Name"
                        />
                        {formik.touched.first_name &&
                        formik.errors.first_name ? (
                          <div className="alert alert-danger" role="alert">
                            {formik.errors.first_name}
                          </div>
                        ) : null}
                      </div>
                    </div>
                    <div className="col-6 col-md-6 col-lg-6">
                      <div className="form-group">
                        <input
                          type="text"
                          name="last_name"
                          id="last_name"
                          value={formik.values.last_name}
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          className="form-control form-control-sm"
                          placeholder="Last Name"
                        />
                        {formik.touched.last_name && formik.errors.last_name ? (
                          <div className="alert alert-danger" role="alert">
                            {formik.errors.last_name}
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </div>
                  <div className="form-group">
                    <input
                      type="email"
                      name="email"
                      id="email"
                      value={formik.values.email}
                      onBlur={formik.handleBlur}
                      onChange={formik.handleChange}
                      className="form-control form-control-sm"
                      placeholder="Email Address"
                    />
                    {formik.touched.email && formik.errors.email ? (
                      <div className="alert alert-danger" role="alert">
                        {formik.errors.email}
                      </div>
                    ) : null}
                  </div>
                  <div className="row">
                    <div className="col-6 col-md-6 col-lg-6">
                      <div className="form-group">
                        <input
                          type="password"
                          name="password"
                          id="password"
                          value={formik.values.password}
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          className="form-control form-control-sm"
                          placeholder="Password"
                        />
                        {formik.touched.password && formik.errors.password ? (
                          <div className="alert alert-danger" role="alert">
                            {formik.errors.password}
                          </div>
                        ) : null}
                      </div>
                    </div>
                    <div className="col-6 col-md-6 col-lg-6">
                      <div className="form-group">
                        <input
                          type="password"
                          name="password_confirmation"
                          id="password_confirmation"
                          value={formik.values.password_confirmation}
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          className="form-control form-control-sm"
                          placeholder="Confirm Password"
                        />
                        {formik.touched.password_confirmation &&
                        formik.errors.password_confirmation ? (
                          <div className="alert alert-danger" role="alert">
                            {formik.errors.password_confirmation}
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </div>
                  <input
                    type="submit"
                    value="Register"
                    className="btn btn-primary"
                  />
                </form>
              </div>
            </div>
            {error && (
              <div className="alert alert-danger m-2" role="alert">
                {error}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default AuthRegister;
