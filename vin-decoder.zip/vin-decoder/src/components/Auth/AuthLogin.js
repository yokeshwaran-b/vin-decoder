import "./AuthRegister.css";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import { userLoginAsync } from "../../store/user-slice";

const AuthLogin = () => {
  const dispatch = useDispatch();

  const error = useSelector((state) => state.user.loginError);
  const onSubmit = (cred) => {
    dispatch(userLoginAsync(cred));
  };

  const validationSchema = Yup.object({
    email: Yup.string()
      .required("Email is Required!")
      .email("Please enter proper email"),
    password: Yup.string()
      .required("Password is Required!")
      .min(8, "Too Short!"),
  });

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    onSubmit,
    validationSchema,
  });
  return (
    <>
      <div className="container mb-5">
        <div className="row centered-form">
          <div className="col-12 col-md-8 col-lg-4 offset-sm-2 offset-md-4">
            <div className="card">
              <div className="card-header">
                <h3 className="card-title">Login in</h3>
              </div>
              <div className="card-body">
                <form onSubmit={formik.handleSubmit}>
                  <div className="form-group">
                    <input
                      type="email"
                      name="email"
                      id="email"
                      value={formik.values.email}
                      onBlur={formik.handleBlur}
                      onChange={formik.handleChange}
                      className="form-control form-control-sm"
                      placeholder="Email Address"
                    />
                    {formik.touched.email && formik.errors.email ? (
                      <div className="alert alert-danger" role="alert">
                        {formik.errors.email}
                      </div>
                    ) : null}
                  </div>

                  <div className="form-group">
                    <input
                      type="password"
                      name="password"
                      id="password"
                      value={formik.values.password}
                      onBlur={formik.handleBlur}
                      onChange={formik.handleChange}
                      className="form-control form-control-sm"
                      placeholder="Password"
                    />
                    {formik.touched.password && formik.errors.password ? (
                      <div className="alert alert-danger" role="alert">
                        {formik.errors.password}
                      </div>
                    ) : null}
                  </div>

                  <input
                    type="submit"
                    value="Register"
                    className="btn btn-primary"
                  />
                </form>
              </div>
            </div>
            {error && (
              <div className="alert alert-danger m-2" role="alert">
                {error}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default AuthLogin;
