import { useSelector, useDispatch } from "react-redux";
import { getVinAsync, addHistoryAsync } from "../store/vin-slice";
import { useParams } from "react-router-dom";
import { useEffect } from "react";

const VinDetail = () => {
  let { id } = useParams();
  const vin = useSelector((state) => state.vin.vinDetails);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getVinAsync(id));
    dispatch(addHistoryAsync(id));
  }, [dispatch, id]);

  if (!vin.Manufacturer && !vin.Make && !vin.Model && !vin.ModelYear) {
    return <p>No Data Found</p>;
  }

  return (
    <div
      className="text-center gradient"
      style={{ margin: "auto", width: "60%" }}
    >
      <h1>VIN Details</h1>
      <div className="card">
        <div className="card-header">General Information</div>
        <ul className="list-group list-group-flush">
          {vin.Manufacturer && (
            <li className="list-group-item">
              Manufacturer - {vin.Manufacturer}
            </li>
          )}
          {vin.Make && <li className="list-group-item">Make - {vin.Make}</li>}
          {vin.Model && (
            <li className="list-group-item">Model - {vin.Model}</li>
          )}
          {vin.ModelYear && (
            <li className="list-group-item">ModelYear - {vin.ModelYear}</li>
          )}
        </ul>
      </div>
    </div>
  );
};

export default VinDetail;
