import { useState } from "react";
import { useHistory } from "react-router-dom";

const Vindercoder = () => {
  const history = useHistory();
  const [vin, setVin] = useState(null);
  const handleClick = (event) => {
    event.preventDefault();
    history.push(`vindecode/${vin}`);
  };

  const handleChange = (event) => {
    setVin(event.target.value);
  };

  return (
    <div className="jumbotron text-center gradient">
      <h1>VIN Decoder</h1>
      <h2>Decoding VIN numbers</h2>
      <h3>
        Enter <strong>VIN number</strong>
      </h3>
      <form onSubmit={handleClick} className="">
        <div className="form-group row">
          <div style={{ margin: "auto", width: "50%" }}>
            <input
              type="text"
              className="form-control"
              id="vin"
              placeholder="VIN NUMBER"
              value={vin}
              name="vin"
              onChange={handleChange}
            />
          </div>
        </div>
        <div className="form-group row">
          <div style={{ margin: "auto", width: "60%" }}>
            <button type="submit" className="btn btn-primary">
              Decode
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Vindercoder;
