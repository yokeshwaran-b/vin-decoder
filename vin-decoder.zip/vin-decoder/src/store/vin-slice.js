import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

import { getVin, getHistory, addHistory } from "./vin-api";

export const getHistoryAsync = createAsyncThunk(
  "vin/getHistoryAsync",
  async () => {
    return await getHistory();
  }
);

export const addHistoryAsync = createAsyncThunk(
  "vin/addHistoryAsync",
  async (vin) => {
    return await addHistory(vin);
  }
);

export const getVinAsync = createAsyncThunk("vin/getVinAsync", async (vin) => {
  return await getVin(vin);
});

const vinSlice = createSlice({
  name: "vin",
  initialState: {
    vinDetails: {},
    history: [],
  },
  reducers: {},
  extraReducers: {
    [getHistoryAsync.pending]: (state) => {
      console.log("getHistoryAsync pending...");
    },
    [getHistoryAsync.fulfilled]: (state, action) => {
      console.log("getHistoryAsync success...");
      state.history = action.payload;
    },
    [getHistoryAsync.rejected]: (state) => {
      console.log("getHistoryAsync error...");
    },

    [addHistoryAsync.pending]: (state) => {
      console.log("addHistoryAsync pending...");
    },
    [addHistoryAsync.fulfilled]: (state, action) => {
      console.log("addHistoryAsync success...");
      state.history = action.payload;
    },
    [addHistoryAsync.rejected]: (state) => {
      console.log("addHistoryAsync error...");
    },

    [getVinAsync.pending]: (state) => {
      console.log("getVinAsync pending...");
    },
    [getVinAsync.fulfilled]: (state, action) => {
      console.log("getVinAsync success...");
      state.vinDetails = action.payload;
      // console.log(state.vinDetails);
    },
    [getVinAsync.rejected]: (state) => {
      console.log("getVinAsync error...");
    },
  },
});

export default vinSlice;
