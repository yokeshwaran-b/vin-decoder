import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

import {
  getUserLoggedin,
  resgisterUser,
  userLogin,
  userLogout,
} from "./user-auth-api";

export const resgisterUserAsync = createAsyncThunk(
  "user/resgisterUserAsync",
  async (newUser, { rejectWithValue }) => {
    try {
      return await resgisterUser(newUser);
    } catch (err) {
      return rejectWithValue(err.response.data.error.message);
    }
  }
);

export const userLoginAsync = createAsyncThunk(
  "user/userLoginAsync",
  async (cred, { rejectWithValue }) => {
    try {
      return await userLogin(cred);
    } catch (err) {
      return rejectWithValue(err.response.data.error.message);
    }
  }
);

export const getLoggedin = createAsyncThunk(
  "user/getLoggedin",
  async (data, { rejectWithValue }) => {
    try {
      return getUserLoggedin();
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const logoutUser = createAsyncThunk(
  "user/logoutUser",
  async (data, { rejectWithValue }) => {
    try {
      return userLogout();
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const userSlice = createSlice({
  name: "user",
  initialState: {
    token: null,
    isLoggedin: false,
    isUserCreated: false,
    userDetails: {
      first_name: "",
    },
  },
  reducers: {},
  extraReducers: {
    [resgisterUserAsync.pending]: (state) => {
      console.log("resgisterUserAsync pending...");
      state.isUserCreated = false;
      state.userCreateError = null;
    },
    [resgisterUserAsync.fulfilled]: (state, action) => {
      console.log("resgisterUserAsync success...");
      state.isUserCreated = true;
      state.userCreateError = null;
      console.log("successfully created user", state.isUserCreated);
    },
    [resgisterUserAsync.rejected]: (state, action) => {
      console.log("resgisterUserAsync error...", action.payload);
      state.userCreateError = action.payload;
      state.isUserCreated = false;
    },

    [userLoginAsync.pending]: (state) => {
      console.log("userLoginAsync pending...");
      state.loginError = null;
    },
    [userLoginAsync.fulfilled]: (state, action) => {
      console.log("userLoginAsync success...");
      state.isLoggedin = true;
      state.loginError = null;
      state.userDetails = action.payload;
    },
    [userLoginAsync.rejected]: (state, action) => {
      console.log("userLoginAsync error...", action.payload);
      console.log("User name or password is wrong...");
      state.loginError = action.payload;
    },

    [getLoggedin.fulfilled]: (state, action) => {
      console.log("getLoggedin success...");
      state.isLoggedin = action.payload.isLoggedin;
      state.token = action.payload.token;
      state.userDetails.first_name = action.payload.first_name;
    },
    [getLoggedin.rejected]: (state, action) => {
      console.log("getLoggedin rejected...", action.payload);
    },

    [logoutUser.fulfilled]: (state, action) => {
      console.log("logoutUser success...", action.payload);
      state.isLoggedin = false;
      state.token = null;
    },
    [logoutUser.rejected]: (state, action) => {
      console.log("logoutUser rejected...", action.payload);
    },
  },
});

export const userActions = userSlice.actions;

export default userSlice;
