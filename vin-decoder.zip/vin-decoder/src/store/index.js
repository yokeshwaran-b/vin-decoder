import { configureStore } from "@reduxjs/toolkit";

import vinSlice from "./vin-slice";
import userSlice from "./user-slice";

const store = configureStore({
  reducer: { vin: vinSlice.reducer, user: userSlice.reducer },
});

export default store;
