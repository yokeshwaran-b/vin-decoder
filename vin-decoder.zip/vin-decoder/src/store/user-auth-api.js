import axios from "axios";
let logoutTimer;

const calculateRemainingTime = (expirationTime) => {
  const currentTime = new Date().getTime();
  const adjExpirationTime = new Date(expirationTime).getTime();

  const remainingDuration = adjExpirationTime - currentTime;

  return remainingDuration;
};

export const retrieveStoredToken = () => {
  const storedToken = localStorage.getItem("token");
  const storedExpirationDate = localStorage.getItem("expirationTime");
  const remainingTime = calculateRemainingTime(storedExpirationDate);

  if (remainingTime <= 3600) {
    localStorage.removeItem("token");
    localStorage.removeItem("expirationTime");
    return null;
  }

  return {
    token: storedToken,
    duration: remainingTime,
  };
};

export const getUserLoggedin = () => {
  const tokenData = retrieveStoredToken();
  let initialToken;
  if (tokenData) {
    initialToken = tokenData.token;
  }
  const token = initialToken;
  const isLoggedin = !!token;

  if (tokenData) {
    console.log(tokenData.duration);
    logoutTimer = setTimeout(logoutUser, tokenData.duration);
  }
  const first_name = localStorage.getItem("first_name");

  return { isLoggedin, token, first_name };
};

export const resgisterUser = async (newUser) => {
  const body = {
    email: newUser.email,
    password: newUser.password,
    returnSecureToken: true,
  };
  let response;
  response = await axios.post(
    "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyByuGhH2m_AyC4j3wcNVNbrx9JQvebr3ro",
    body
  );
  if (response.status === 200) {
    const path =
      "https://vin-decoder-2ed08-default-rtdb.firebaseio.com/users/" +
      response.data.localId +
      ".json";

    await axios.put(path, newUser, {
      "Content-Type": "application/json",
    });
  }
  return response;
};

export const userLogin = async (cred) => {
  let response;
  const body = {
    email: cred.email,
    password: cred.password,
    returnSecureToken: true,
  };
  response = await axios.post(
    "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyByuGhH2m_AyC4j3wcNVNbrx9JQvebr3ro",
    body
  );
  let response2;
  if (response.status === 200) {
    response2 = await axios.get(
      `https://vin-decoder-2ed08-default-rtdb.firebaseio.com/users/${response.data.localId}.json`
    );
  }
  const expirationTime = new Date(
    new Date().getTime() + +response.data.expiresIn * 1000
  );
  const payload = {
    idToken: response.data.idToken,
    expirationTime,
    first_name: response2.data.first_name,
    last_name: response2.data.first_name,
  };

  window.localStorage.setItem("token", payload.idToken);
  window.localStorage.setItem(
    "expirationTime",
    payload.expirationTime.toISOString()
  );
  window.localStorage.setItem("first_name", payload.first_name);
  const remainingTime = calculateRemainingTime(
    payload.expirationTime.toISOString()
  );
  logoutTimer = setTimeout(logoutUser, remainingTime);

  return payload;
};

export const userLogout = () => {
  logoutUser();
  return false;
};

function logoutUser() {
  localStorage.removeItem("token");
  localStorage.removeItem("expirationTime");
  localStorage.removeItem("first_name");
  console.log("local storage removed");

  if (logoutTimer) {
    clearTimeout(logoutTimer);
  }
}
