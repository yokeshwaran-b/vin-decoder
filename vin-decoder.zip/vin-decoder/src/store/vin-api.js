import axios from "axios";

export const getVin = async (vin) => {
  const response = await axios.get(
    `https://vpic.nhtsa.dot.gov/api/vehicles/decodevinvalues/${vin}?format=json`
  );
  const vinDetails = {
    Manufacturer: response.data.Results[0].Manufacturer,
    Make: response.data.Results[0].Make,
    Model: response.data.Results[0].Model,
    ModelYear: response.data.Results[0].ModelYear,
  };
  return vinDetails;
};

export const getHistory = async () => {
  const response = await axios.get(
    "https://vin-decoder-2ed08-default-rtdb.firebaseio.com/history.json"
  );
  const history = response.data;
  return history;
};

export const addHistory = async (newEntry) => {
  const response1 = await axios.get(
    "https://vin-decoder-2ed08-default-rtdb.firebaseio.com/history.json"
  );
  let history = response1.data;
  if (history.length >= 10) {
    history = history.slice(1);
  }
  history.push(newEntry);
  const response2 = await axios.put(
    "https://vin-decoder-2ed08-default-rtdb.firebaseio.com/history.json",
    history,
    { "Content-Type": "application/json" }
  );
  return response2.data;
};
