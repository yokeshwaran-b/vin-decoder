import Vindercoder from "./components/Vindecoder";
import History from "./components/History";
import { Switch, Route, Link, useHistory, Redirect } from "react-router-dom";
import VinDetail from "./components/VinDetail";

import { useDispatch, useSelector } from "react-redux";
import { getHistoryAsync } from "./store/vin-slice";
import { useEffect } from "react";
import AuthRegister from "./components/Auth/AuthRegister";
import AuthLogin from "./components/Auth/AuthLogin";
import { getLoggedin, logoutUser } from "./store/user-slice";
import HomePage from "./components/HomePage";

function App() {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getHistoryAsync());
    dispatch(getLoggedin());
  }, [dispatch]);
  const isLoggedIn = useSelector((state) => state.user.isLoggedin);
  const firstName = useSelector((state) => state.user.userDetails.first_name);

  const history = useHistory();

  const handleLogout = (e) => {
    e.preventDefault();
    dispatch(logoutUser());
    history.push("/");
  };

  return (
    <div>
      {/* <BrowserRouter> */}
      <div className="container">
        <nav id="navbar-example2" className="navbar navbar-light bg-light">
          <span className="navbar-brand">VinDecoder</span>
          <ul className="nav nav-pills">
            <li className="nav-item">
              <Link to="/" className="nav-link">
                HOME
              </Link>
            </li>
            {isLoggedIn && (
              <li className="nav-item">
                <Link to="vindecode" className="nav-link">
                  VIN DECODE
                </Link>
              </li>
            )}
            {!isLoggedIn && (
              <li className="nav-item">
                <Link to="register" className="nav-link">
                  Register
                </Link>
              </li>
            )}
            {!isLoggedIn && (
              <li className="nav-item">
                <Link className="nav-link" to="login">
                  Login
                </Link>
              </li>
            )}
            {isLoggedIn && (
              <li className="nav-item dropdown">
                <span
                  className="nav-link dropdown-toggle"
                  data-toggle="dropdown"
                  role="button"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  {firstName && <span>{firstName}</span>}
                </span>
                <div className="dropdown-menu">
                  {/* <span className="dropdown-item">Profile</span> */}
                  {/* <span className="dropdown-item">Change Password</span> */}

                  {/* {isLoggedIn && (
                  <div> */}
                  {/* <div role="separator" className="dropdown-divider"></div> */}
                  <button className="dropdown-item" onClick={handleLogout}>
                    Logout
                  </button>
                </div>
              </li>
            )}
          </ul>
        </nav>

        <Switch>
          <Route exact path="/">
            <HomePage />
          </Route>
          {!isLoggedIn && (
            <Route path="/login">
              <AuthLogin />
            </Route>
          )}
          {!isLoggedIn && (
            <Route path="/Register">
              <AuthRegister />
            </Route>
          )}
          {isLoggedIn && (
            <Route exact path="/vindecode">
              <Vindercoder />
              <History />
            </Route>
          )}
          {isLoggedIn && (
            <Route path="/vindecode/:id">
              <VinDetail />
            </Route>
          )}

          <Route path="*">
            {!isLoggedIn && <Redirect to="/" />}
            {isLoggedIn && <Redirect to="vindecode" />}
          </Route>
        </Switch>
      </div>
    </div>
  );
}

export default App;
